# SmoothPlayer — 比 Bubble Player 更順暢的 Android 原生影片播放器

## 設計目標

- **無廣告**：App 內不插入任何廣告。
- **一開啟即連 YouTube**：主畫面提供一鍵開啟 YouTube 官方 App／網頁。
- **極低卡頓與轉圈**：智慧緩衝 + 卡頓趨勢偵測 + 動態位元率限制，避免長時間 buffering 轉圈。
- **網路韌性**：
  - 即時網路連線監測
  - Wi-Fi／行動網路切換偵測
  - 斷線後保留播放器狀態與位置
  - 網路恢復後自動恢復播放
- **智慧畫質**：
  - 卡頓風險升高時主動限制最高影片位元率
  - 網路穩定後交回自適應畫質選擇
- **播放錯誤恢復**：最多 4 次遞進式恢復，避免無限 prepare → play 死循環。
- **格式支援**：MP4、HLS、DASH（HTTP/HTTPS）。
- **播放功能**：倍速 0.5×～2×、±10 秒、全螢幕、音量／亮度手勢預留、硬體解碼優先。
- **低記憶體優化**：精簡緩衝策略、SharedPreferences 存位置。
- **目標**：Android 11（API 30）以上，Media3 / ExoPlayer 1.10.1。

## 技術規格

| 項目 | 版本 |
|------|------|
| Media3 / ExoPlayer | 1.10.1 |
| Android Gradle Plugin | 9.3.0 |
| Gradle | 9.5 |
| JDK | 17 |
| minSdk | 30 (Android 11) |
| targetSdk / compileSdk | 36 |
| 語言 | Kotlin |

## 專案結構

```
SmoothPlayer/
├── app/
│   ├── build.gradle.kts
│   ├── src/main/
│   │   ├── AndroidManifest.xml
│   │   ├── java/com/smoothplayer/app/
│   │   │   ├── SmoothPlayerApp.kt
│   │   │   ├── network/NetworkMonitor.kt
│   │   │   ├── player/
│   │   │   │   ├── SmoothPlayerManager.kt      # 核心播放管理
│   │   │   │   ├── SmartLoadControl.kt        # 智慧緩衝
│   │   │   │   ├── StallDetector.kt           # 卡頓偵測
│   │   │   │   ├── ErrorRecoveryHandler.kt    # 錯誤恢復
│   │   │   │   ├── PlaybackPositionStore.kt   # 位置保存
│   │   │   │   └── PlaybackService.kt         # 預留背景播放
│   │   │   └── ui/
│   │   │       ├── MainActivity.kt
│   │   │       └── PlayerActivity.kt
│   │   └── res/
│   │       ├── layout/
│   │       └── values/
├── build.gradle.kts
├── settings.gradle.kts
└── gradle.properties
```

## 核心機制說明

### 1. 智慧緩衝（SmartLoadControl）
依據 NetworkCapabilities 回報的下游頻寬動態調整 `minBufferMs` / `maxBufferMs`：
- 高頻寬（≥5 Mbps）：較大緩衝，減少卡頓風險
- 中頻寬：標準值
- 低頻寬：縮小目標緩衝，優先連續播放

### 2. 卡頓趨勢偵測（StallDetector）
每 800ms 檢查 `bufferedPosition - currentPosition` 與 `STATE_BUFFERING`：
- 風險升高 → 主動降低 `maxVideoBitrate`
- 穩定後 → 解除限制，交回 ExoPlayer 自適應

### 3. 錯誤恢復（ErrorRecoveryHandler）
最多 4 次：
1. 簡單 re-prepare
2. 重新建立 MediaItem
3. 強制降到約 1.5 Mbps 後重試
4. 再降到約 0.8 Mbps 後最後嘗試

每次保留播放位置，並有遞增延遲，避免死循環。

### 4. 網路監測與恢復
`NetworkMonitor` 使用 `ConnectivityManager.NetworkCallback` 監聽：
- 連線／斷線
- Wi-Fi ↔ 行動網路
- 頻寬估算

斷線時 `playWhenReady = false` 並存位置；恢復後自動 seek + prepare + play。

### 5. UI 設計
乾淨深色介面：
- 影片區
- 播放／暫停、±10 秒
- 進度條
- 畫質提示、倍速選擇
- 全螢幕、鎖定觸控
- 最小化緩衝指示器（僅真正需要時短暫顯示）

## 建置方式（手機／GitHub）

### 使用 Android Studio（推薦）
1. 將整個 `SmoothPlayer` 資料夾匯入 Android Studio。
2. 同步 Gradle（使用 JDK 17）。
3. 連接手機（Android 11+）或模擬器，直接 Run。

### 使用命令列
```bash
cd SmoothPlayer
./gradlew assembleDebug
# APK 位於 app/build/outputs/apk/debug/app-debug.apk
```

### 透過 GitHub Actions 自動建置 APK
可自行新增 `.github/workflows/build.yml`，在 Actions 下載 artifact。

## 後續可擴充

- 浮動視窗（Picture-in-Picture）
- 背景播放 + MediaSession 通知列控制
- 播放清單與預載入下一支影片
- 手勢調音量／亮度
- 字幕支援
- 更精準的實際下載速度量測（結合 DataSource 統計）

## 授權與注意事項

- 本專案僅供學習與個人使用。
- 播放第三方內容請遵守其服務條款與版權規定。
- YouTube 入口會開啟官方 App／網頁，YouTube 本身的廣告由 Google 控制，App 內不插入額外廣告。

---
SmoothPlayer — 專為手機原生環境打造，追求「無延遲、無轉圈、網路波動也能繼續看」的播放體驗。
