# Media3 / ExoPlayer
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**

# Keep player state
-keepclassmembers class * {
    @androidx.annotation.Keep *;
}
